#!/bin/sh

/usr/lib/deepin-graphics-driver-manager/intel/remove_intel_opensource.sh 0
